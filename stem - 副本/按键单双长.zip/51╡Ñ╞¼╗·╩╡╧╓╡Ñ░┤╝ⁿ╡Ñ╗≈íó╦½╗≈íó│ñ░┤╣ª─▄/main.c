#include <reg51.h>
#include "keyboard.h"

unsigned char timer_10ms_flag = 0;
unsigned char key;

void Timer0_init(void);

void main(void)
{
	key_init();
	Timer0_init();
	
	while(1)
	{
		if(timer_10ms_flag&key_flag == 1)
		{
			timer_10ms_flag &= clear_key_flag;
			key = key_read();
			
			switch(key)
			{
				case key_click:
					//put your code here
				break;
				case key_double:
					//put your code here
				break;
				case key_long:
					//put your code here
				break;
			}
		}
	}
}

void Timer0_init(void)
{
	TMOD = 0x01;  //using timer0 mode1
	TH0 = (65535 - 10000)/256;
	TL0 = (65535 - 10000)%256;  //set timer0
	EA = 1;  //enable the interrupt
	ET0 = 1;  //enable the timer0 interrupt
	TR0 = 1;  //enable the timer0	
}


void timer0_isr(void) interrupt 1
{
	TH0 = (65535 - 10000)/256;
	TL0 = (65535 - 10000)%256; //reset timer0
	timer_10ms_flag |= key_flag;   //reset time 10ms flag
}





