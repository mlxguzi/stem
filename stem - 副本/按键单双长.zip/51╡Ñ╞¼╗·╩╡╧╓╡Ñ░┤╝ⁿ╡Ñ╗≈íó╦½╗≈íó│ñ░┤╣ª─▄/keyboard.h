#ifndef _KEYBOARD_H_
#define _KEYBOARD_H_

#include <reg51.h>

sbit key_input = P2^0;

#define key_no	   0    //no keys
#define key_click  1    //click keys
#define key_double 2    //double click
#define key_long   3    //long click

#define key_state_0		0
#define key_state_1   1
#define key_state_2   2
#define key_state_3   3 //key states define

#define key_flag	(1<<0)
#define clear_key_flag  (~(1<<0))

#define key_init()	(key_input = 1)

extern unsigned char key_read();

#endif
