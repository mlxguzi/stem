
#include "N76E003.h"
#include "Common.h"
#include "Delay.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "intrins.h"


/* Private variables ---------------------------------------------------------*/
#define numLEDs 6
sbit LED_input = P0^6 ;

#define LED_RING_DATE_PIN_LOW() (LED_input = 0) 
#define LED_RING_DATE_PIN_HIGH() (LED_input = 1) 
#define TH0_INIT        50000 
#define TL0_INIT        50000
#define TH1_INIT        25000 
#define TL1_INIT        25000

UINT8 u8TH0_Tmp,u8TL0_Tmp,j=0;

uint8_t ring_brightness_duty = 255;//0-255
void Timer0_ISR (void) interrupt 1  //interrupt address is 0x000B
{
    TH0 = u8TH0_Tmp;
    TL0 = u8TL0_Tmp;    
    j++;

}


void H1_nop_800ns(){
	_nop_();_nop_();_nop_();

}

void H0_nop_400ns(){
	_nop_();
}


void Din_1(void) {
	LED_RING_DATE_PIN_HIGH();
	H1_nop_800ns();
	LED_RING_DATE_PIN_LOW();
	//L1_nop_450ns();
}

void Din_0(void) {
	LED_RING_DATE_PIN_HIGH();
//	H0_nop_400ns();
	_nop_();_nop_(); //��ʱ400ns
	LED_RING_DATE_PIN_LOW();
	//L0_nop_850ns();
}

void Send_8bits(uint8_t dat) {
	uint8_t i;
	for(i=0;i<8;i++) {
		if(dat & 0x80) {//1,for "1",H:0.8us,L:0.45us;
			Din_1();
		} else {		//0,for "0",H:0.4us,L:0.85us
			Din_0();
		}
		dat=dat<<1;
	}
}

void Send_2811_24bits(uint8_t RData, uint8_t GData, uint8_t BData) {
	//G--R--B
	Send_8bits(GData*(ring_brightness_duty/255));
	Send_8bits(RData*(ring_brightness_duty/255));
	Send_8bits(BData*(ring_brightness_duty/255));
 }

 void rst() {
	LED_RING_DATE_PIN_LOW();
	//HAL_Delay (1);
}

void ring_set_color_all_same(uint8_t r, uint8_t g, uint8_t b) {
	uint8_t i;
	for(i=0;i<numLEDs;i++) {
		Send_2811_24bits(r,g,b);
	}
	
}

void ring_display_clear(){
	uint8_t i;
	for( i=0; i<numLEDs; i++) {
		Send_2811_24bits(0,0,0);
	}
}

void main(void)
{
		
    Set_All_GPIO_Quasi_Mode;
#if 1
		TIMER0_MODE1_ENABLE;
    u8TH0_Tmp = (65536-TH0_INIT)/256;
    u8TL0_Tmp = (65536-TL0_INIT)%256; 
    TH0 = u8TH0_Tmp;
    TL0 = u8TL0_Tmp;	
	  set_ET0; 
	  set_EA; 
	  set_TR0;                                    
#endif	

while(1)
{	
  	ring_set_color_all_same(0xff, 0xff, 0xf1);
		while(j>200)
		{
			j=0;
			P12 = ~P12;
		}
		ring_set_color_all_same(0x10, 0x23, 0x33);
}	
//		while(j>200);

//		clr_GPIO1;
	  ring_set_color_all_same(0xf2, 0x55, 0x01);
//		ring_display_clear();
//	  ring_set_color_all_same(0x11, 0x85, 0xf0);
	
}


/************************ (C) COPYRIGHT OAZON ******************END OF FILE****/


