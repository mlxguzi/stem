#include "N76E003.h"
#include "Common.h"
#include "Delay.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "PWM1.h"


/************************************************************************************************************
*    Main function 
************************************************************************************************************/
void PWM1(void)
{
    Set_All_GPIO_Quasi_Mode;

		PWM0_P12_OUTPUT_ENABLE;
		PWM2_P10_OUTPUT_DISABLE;
		PWM4_P01_OUTPUT_ENABLE;
		PWM5_P03_OUTPUT_ENABLE;
	
		PWM_IMDEPENDENT_MODE;
		PWM_CLOCK_DIV_8;
		PWMPH = 0x07;
		PWMPL = 0xCF;
/**********************************************************************
	PWM frequency = Fpwm/((PWMPH,PWMPL) + 1) <Fpwm = Fsys/PWM_CLOCK_DIV> 
								= (16MHz/8)/(0x7CF + 1)
								= 1KHz (1ms)
***********************************************************************/
	
		PWM0H = 0x00;					
		PWM0L = 0xCF;
		PWM2H = 0x01;						
		PWM2L = 0xCF;
		
		set_SFRPAGE;						//PWM4 and PWM5 duty seting is in SFP page 1
		PWM4H = 0x03;						
		PWM4L = 0xCF;
		PWM5H = 0x05;						
		PWM5L = 0xCF;
		clr_SFRPAGE;											
// PWM output inversly enable 
		PWM2_OUTPUT_INVERSE;

//-------- PWM start run--------------
    set_LOAD;
    set_PWMRUN;
		while(1);
}