#include "N76E003.h"
#include "SFR_Macro.h"
#include "Function_define.h"
#include "Common.h"
#include "Delay.h"
#include "ADC1.h"

//*****************  The Following is in define in Fucntion_define.h  ***************************
//****** Always include Function_define.h call the define you want, detail see main(void) *******
//***********************************************************************************************

/******************************************************************************
The main C function.  Program execution starts
here after stack initialization.
******************************************************************************/
void ADC1 (void) 
{
		InitialUART0_Timer1(115200);
 
		Enable_ADC_AIN3;						// Enable AIN0 P1.7 as ADC input, Find in "Function_define.h" - "ADC INIT"
		while(1)
    {
			clr_ADCF;
			set_ADCS;									// ADC start trig signal
      while(ADCF == 0);
			printf ("\n Value = 0x%bx",ADCRH);
			printf ("\n Value = 0x%bx",ADCRL);
			Timer0_Delay1ms(100);
    }
}


