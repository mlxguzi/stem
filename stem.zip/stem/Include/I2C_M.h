void Init_I2C(void);
void I2C_Error(void);
void I2C_Process(UINT8 u8DAT);
void IIC1(void);